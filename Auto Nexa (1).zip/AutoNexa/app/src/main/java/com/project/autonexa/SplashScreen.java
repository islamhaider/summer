package com.project.autonexa;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.project.autonexa.databinding.ActivitySplashScreenBinding;

@SuppressLint("CustomSplashScreen")
public class SplashScreen extends AppCompatActivity {
    ActivitySplashScreenBinding binding;
    Animation slideUp;
    String moveTo = "";
    FirebaseUser user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivitySplashScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            getWindow().setStatusBarColor(getColor(R.color.white));
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        user = FirebaseAuth.getInstance().getCurrentUser();

        getUserData(user);

        slideUp = AnimationUtils.loadAnimation(this,R.anim.slide_up);
        binding.splashLogo.setAnimation(slideUp);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
//                if (moveTo.isEmpty()){
//                    startActivity(new Intent(SplashScreen.this, LoginSignUpActivity.class));
//                    finish();
//                }else{
//                    if (moveTo.equals("main")){
//                        startActivity(new Intent(SplashScreen.this, Home.class));
//                        finish();
//                    }else{
//                        startActivity(new Intent(SplashScreen.this, ProfileSetupActivity.class));
//                        finish();
//                    }
//                }
                startActivity(new Intent(SplashScreen.this, Home.class));
                        finish();
            }
        }, 3000);
    }

    private void getUserData(FirebaseUser user) {
        if (user!=null){
            FirebaseDatabase.getInstance().getReference().child("Users")
                    .child(user.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()){
                                moveTo = "main";
                            }else{
                                moveTo = "profile";
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
        }
    }
}