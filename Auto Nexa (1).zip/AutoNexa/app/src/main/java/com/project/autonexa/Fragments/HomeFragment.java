package com.project.autonexa.Fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.project.autonexa.R;
import com.project.autonexa.databinding.FragmentHomeBinding;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    FragmentHomeBinding binding;
    ArrayList<SlideModel> images;
    Context context;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater,container,false);
        context = requireContext();
        images = new ArrayList<>();
        images.add(new SlideModel(R.drawable.b3, ScaleTypes.FIT));
        images.add(new SlideModel(R.drawable.b4, ScaleTypes.FIT));
        images.add(new SlideModel(R.drawable.b1, ScaleTypes.FIT));
        images.add(new SlideModel(R.drawable.b2, ScaleTypes.FIT));
        binding.imageSlider.setImageList(images, ScaleTypes.FIT);


        return binding.getRoot();
    }
}