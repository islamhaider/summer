package com.project.autonexa;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionUtils {

    public static final int LOCATION_PERMISSION_REQUEST_CODE = 100;
    public static final int CAMERA_PERMISSION_REQUEST_CODE = 101;
    public static final int STORAGE_PERMISSION_REQUEST_CODE = 102;

    public static boolean checkPermission(Context context, String permission) {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED;
    }

    public static void requestPermission(Activity activity, String permission, int requestCode) {
        ActivityCompat.requestPermissions(activity, new String[]{permission}, requestCode);
    }

    public static boolean checkLocationPermission(Context context) {
        return checkPermission(context, Manifest.permission.ACCESS_FINE_LOCATION);
    }

    public static void requestLocationPermission(Activity activity) {
        requestPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION, LOCATION_PERMISSION_REQUEST_CODE);
    }

    public static boolean checkCameraPermission(Context context) {
        return checkPermission(context, Manifest.permission.CAMERA);
    }

    public static void requestCameraPermission(Activity activity) {
        requestPermission(activity, Manifest.permission.CAMERA, CAMERA_PERMISSION_REQUEST_CODE);
    }

    public static boolean checkStoragePermission(Context context) {
        if (Build.VERSION.SDK_INT >= 33) {
            return checkPermission(context, Manifest.permission.READ_MEDIA_IMAGES);
        }else{
            return checkPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE);
        }

    }

    public static void requestStoragePermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermission(activity, Manifest.permission.READ_MEDIA_IMAGES, STORAGE_PERMISSION_REQUEST_CODE);
        }else{
            requestPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE, STORAGE_PERMISSION_REQUEST_CODE);
        }
    }
}

