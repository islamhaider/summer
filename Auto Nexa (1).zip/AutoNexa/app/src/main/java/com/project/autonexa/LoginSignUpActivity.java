package com.project.autonexa;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.project.autonexa.databinding.ActivityLoginSignUpBinding;

import java.util.Objects;

public class LoginSignUpActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener {
    private GoogleSignInClient mGoogleSignInClient;
    private static final int RC_SIGN_IN = 1;
    String name, email;
    Uri uri;
    String idToken;
    private boolean isSignIn = true;
    private FirebaseAuth firebaseAuth;
    ActivityLoginSignUpBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityLoginSignUpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            getWindow().setStatusBarColor(getColor(R.color.colorPrimary));
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        firebaseAuth = FirebaseAuth.getInstance();
        binding.btnForgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginSignUpActivity.this, ResetPasswordActivity.class));
            }
        });
        binding.btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.llLogin.setVisibility(View.VISIBLE);
                binding.llSignUp.setVisibility(View.GONE);
                binding.btnForgetPassword.setVisibility(View.VISIBLE);
                binding.confirmPassword.setVisibility(View.GONE);
                isSignIn = true;
            }
        });
        binding.btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.llSignUp.setVisibility(View.VISIBLE);
                binding.btnForgetPassword.setVisibility(View.GONE);
                binding.llLogin.setVisibility(View.GONE);
                binding.confirmPassword.setVisibility(View.VISIBLE);
                isSignIn = false;
            }
        });

        binding.btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = binding.email.getText().toString();
                final String password = binding.password.getText().toString();
                final String confirmPassword = binding.confirmPassword.getText().toString();

                if(email.length()==0) {
                    binding.email.setError("Enter Email");
                    return;
                }
                if(password.length()==0) {
                    binding.password.setError("Enter Password");
                    return;
                }
                if (!isSignIn) {
                    if (confirmPassword.length() == 0) {
                        binding.confirmPassword.setError("Confirm Password");
                        return;
                    }


                    if (!confirmPassword.equals(password)) {
                        binding.confirmPassword.setError("Password does not match, Confirm your password.");
                        return;
                    }
                }

                binding.progress.setVisibility(View.VISIBLE);
                if (isSignIn){
                    login(email, password);
                }else{
                    register(email, password);
                }

            }
        });

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("567028834860-gqfbgm2arnfo3om7mnfc2pppodns4bvf.apps.googleusercontent.com")
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(LoginSignUpActivity.this, gso);

        SignInButton signInButton = findViewById(R.id.sign_in_button);
        signInButton.setOnClickListener(view -> {
            Intent signInIntent = mGoogleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, RC_SIGN_IN);
        });

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            binding.progress.setVisibility(View.VISIBLE);
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            handleSignInResult(result);
        }
    }
    private void handleSignInResult(GoogleSignInResult result) {
        if (result.isSuccess()) {
            GoogleSignInAccount account = result.getSignInAccount();
            idToken = Objects.requireNonNull(account).getIdToken();
            name = account.getDisplayName();
            email = account.getEmail();
            uri = account.getPhotoUrl();
            AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
            firebaseAuthWithGoogle(credential);
        } else {
            binding.progress.setVisibility(View.GONE);
            Toast.makeText(LoginSignUpActivity.this, "Login Unsuccessful", Toast.LENGTH_SHORT).show();
        }
    }

    private void firebaseAuthWithGoogle(AuthCredential credential) {
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(LoginSignUpActivity.this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseDatabase.getInstance().getReference("Users")
                                .child(Objects.requireNonNull(FirebaseAuth.getInstance().getUid()))
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        binding.progress.setVisibility(View.GONE);
                                        if (!snapshot.exists()){
                                            startActivity(new Intent(LoginSignUpActivity.this, ProfileSetupActivity.class)
                                                    .putExtra("name", name).putExtra("uri", uri.toString()));
                                        }else{
                                            startActivity(new Intent(LoginSignUpActivity.this, Home.class));
                                        }
                                        finish();
                                        Toast.makeText(LoginSignUpActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });

                    } else {
                        binding.progress.setVisibility(View.GONE);
                        task.getException().printStackTrace();
                        Toast.makeText(LoginSignUpActivity.this, "Authentication failed.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void login(String email, String password) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password).addOnCompleteListener(LoginSignUpActivity.this, task -> {
            if (!task.isSuccessful()) {
                binding.progress.setVisibility(View.GONE);
                Toast.makeText(this, "Sign in error", Toast.LENGTH_SHORT).show();
            }else{
                binding.progress.setVisibility(View.GONE);

                    if (Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).isEmailVerified()){
                        Toast.makeText(this, "Sign In Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(LoginSignUpActivity.this, Home.class));
                        finish();
                    }else{
                        Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).sendEmailVerification().addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(LoginSignUpActivity.this, "Something went wrong.", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(LoginSignUpActivity.this, "Email not verified, A verification email sent to your mail. Verify you mail first.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

            }
        });
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
    private void register(String email, String password){
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password).addOnCompleteListener(LoginSignUpActivity.this, task -> {
            if (!task.isSuccessful()) {
                binding.progress.setVisibility(View.GONE);
                Toast.makeText(this, "Something went wrong.", Toast.LENGTH_SHORT).show();
            }else{
                binding.progress.setVisibility(View.GONE);
                Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).sendEmailVerification().addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(LoginSignUpActivity.this, "Something went wrong.", Toast.LENGTH_SHORT).show();
                    }
                }).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        FirebaseDatabase.getInstance().getReference("AppSettings")
                                .child(Objects.requireNonNull(FirebaseAuth.getInstance().getUid()))
                                .child("notificationEnabled").setValue(true);
                        Toast.makeText(LoginSignUpActivity.this, "Registered Successfully, Check inbox & verify your mail.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }


}