package com.project.autonexa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;


import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.project.autonexa.databinding.ActivityProfileSetupBinding;

import java.util.HashMap;
import java.util.Objects;



public class ProfileSetupActivity extends AppCompatActivity {
    private static final String TAG = "IslamHaider";
    private static final int REQUEST_GALLERY = 100000;
    ActivityProfileSetupBinding binding;
    ProfileModel profileModel;

    String[] genderSpinnerStrings = {"Select Gender", "Male", "Female"};
    Uri imageUri;
    boolean toUpdateData = false;
    boolean toUpdateImage = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProfileSetupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            getWindow().setStatusBarColor(getColor(R.color.colorPrimary));
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String imageName = "avatar";
        Resources resources = getResources();
        int resourceId = resources.getIdentifier(imageName, "drawable", getPackageName());
        if (resourceId != 0) {
            imageUri = Uri.parse("android.resource://" + getPackageName() + "/" + resourceId);
        }


        ArrayAdapter<String> gendersAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, genderSpinnerStrings);
        gendersAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.gender.setAdapter(gendersAdapter);

        Intent intentData = getIntent();
        if (intentData!= null){
            if (intentData.hasExtra("from")){
                toUpdateData = true;
                binding.btnSubmit.setText("Update");
                FirebaseDatabase.getInstance().getReference("Users")
                        .child(Objects.requireNonNull(FirebaseAuth.getInstance().getUid()))
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()){
                                    ProfileModel profile = snapshot.getValue(ProfileModel.class);
                                    Glide.with(ProfileSetupActivity.this)
                                            .load(Objects.requireNonNull(profile).getImage())
                                            .into(binding.profileImageView);
                                    binding.fn.setText(profile.getFirstName());
                                    binding.ln.setText(profile.getLastName());
                                    binding.age.setText(profile.getAge()+"");
                                    binding.imgAddBtn.setVisibility(View.GONE);

                                    int i=0;
                                    for (String s: genderSpinnerStrings){
                                        if (s.equals(profile.getGender())){
                                            binding.gender.setSelection(i);
                                            break;
                                        }
                                        i++;
                                    }



                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
            }
        }



        Intent intent = getIntent();
        if (intent!= null) {
            if (intent.hasExtra("name")) {
                binding.fn.setText(intent.getStringExtra("name"));
            }
        }


        binding.btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (areFieldsReady()){
                    binding.progress.setVisibility(View.VISIBLE);
                    if (toUpdateData && !toUpdateImage){
                        updateOnFirebase(profileModel);
                    }else{
                        postDataOnFirebase(profileModel);
                    }

                }
            }
        });



        binding.profileImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (PermissionUtils.checkStoragePermission(ProfileSetupActivity.this)){
                    openGallery();
                }else{
                    PermissionUtils.requestStoragePermission(ProfileSetupActivity.this);
                }
            }
        });

    }

    private void updateOnFirebase(ProfileModel model) {
        HashMap<String, Object> updateMap = new HashMap<>();
        updateMap.put("firstName", model.getFirstName());
        updateMap.put("lastName", model.getLastName());
        updateMap.put("gender", model.getGender());
        if (toUpdateImage){
            updateMap.put("image", model.getImage());
        }

        FirebaseDatabase.getInstance().getReference("Users").child(Objects.requireNonNull(FirebaseAuth.getInstance().getUid())).updateChildren(updateMap).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                binding.progress.setVisibility(View.GONE);
                Log.d(TAG, "onFailure: " + e.getMessage());
                Toast.makeText(ProfileSetupActivity.this, "Something went wrong please try again.", Toast.LENGTH_SHORT).show();
            }
        }).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                binding.progress.setVisibility(View.GONE);
                Toast.makeText(ProfileSetupActivity.this, "Profile Saved", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(ProfileSetupActivity.this, Home.class));
                finish();
            }
        });
    }

    private void postOnFirebase(ProfileModel model) {
        FirebaseDatabase.getInstance().getReference("Users").child(Objects.requireNonNull(FirebaseAuth.getInstance().getUid())).setValue(model).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                binding.progress.setVisibility(View.GONE);
                Log.d(TAG, "onFailure: " + e.getMessage());
                Toast.makeText(ProfileSetupActivity.this, "Something went wrong please try again.", Toast.LENGTH_SHORT).show();
            }
        }).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                binding.progress.setVisibility(View.GONE);
                Toast.makeText(ProfileSetupActivity.this, "Profile Saved", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(ProfileSetupActivity.this, Home.class));
                finish();
            }
        });
    }

    public void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent, REQUEST_GALLERY);
    }
    private void postDataOnFirebase(ProfileModel profileModel) {
        String uid = Objects.requireNonNull(FirebaseAuth.getInstance().getUid());
        StorageReference imageRef = FirebaseStorage.getInstance().getReference().child("ProfileImages").child(uid +".jpg");
        UploadTask uploadTask = imageRef.putFile(imageUri);
        uploadTask.addOnSuccessListener(taskSnapshot -> {
            imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                String downloadUrl = uri.toString();
                profileModel.setImage(downloadUrl);
                if (toUpdateImage){
                    updateOnFirebase(profileModel);
                }else{
                    postOnFirebase(profileModel);
                }
            }).addOnFailureListener(exception -> {
                binding.progress.setVisibility(View.GONE);
                Log.d(TAG, "onFailure: " + exception.getMessage());
                Toast.makeText(ProfileSetupActivity.this, "Something went wrong please try again.", Toast.LENGTH_SHORT).show();
            });
        }).addOnFailureListener(exception -> {
            binding.progress.setVisibility(View.GONE);
            Log.d(TAG, "onFailure: " + exception.getMessage());
            Toast.makeText(ProfileSetupActivity.this, "Something went wrong please try again.", Toast.LENGTH_SHORT).show();
        });
    }

    private boolean areFieldsReady() {

        profileModel = new ProfileModel(binding.fn.getText().toString(),
                binding.ln.getText().toString(),
                binding.gender.getSelectedItem().toString(),
                Integer.parseInt(binding.age.getText().toString())
        );
        if (profileModel.getFirstName().isEmpty()){
            binding.fn.setError("Enter First Name");
            return false;
        }
        if (profileModel.getLastName().isEmpty()){
            binding.ln.setError("Enter Last Name");
            return false;
        }
        if (binding.age.getText().toString().isEmpty()){
            binding.age.setError("Enter Age");
            return false;
        }


        if (profileModel.getGender().isEmpty()  || profileModel.getGender().equalsIgnoreCase("Select Gender")){
            Toast.makeText(this, "Select Gender", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_GALLERY && resultCode == Activity.RESULT_OK && data != null) {
            if (data.getData() != null) {
                Uri selectedImageUri = data.getData();
                if (selectedImageUri != null) {
                    if (toUpdateData){
                        toUpdateImage = true;
                    }
                    binding.imgAddBtn.setVisibility(View.GONE);
                    binding.profileImageView.setImageURI(selectedImageUri);
                    imageUri = selectedImageUri;
                }
            }

        }
    }
}