package com.project.autonexa;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.project.autonexa.Fragments.HomeFragment;
import com.project.autonexa.Fragments.MyAdsFragment;
import com.project.autonexa.Fragments.PrivacyPolicyFragment;
import com.project.autonexa.Fragments.ProfileFragment;
import com.project.autonexa.Fragments.RentACarFragment;
import com.project.autonexa.Fragments.WorkshopsFragment;
import com.project.autonexa.databinding.ActivityHomeBinding;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    DrawerLayout drawer;
    ActivityHomeBinding binding;
    PrivacyPolicyFragment privacyPolicyFragment;
    HomeFragment homeFragment;
    RentACarFragment rentACarFragment;
    MyAdsFragment myAdsFragment;
    ProfileFragment profileFragment;
    WorkshopsFragment workshopsFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimary));

        Toolbar toolbar = findViewById(R.id.home_toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle(getString(R.string.app_name));
        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, new HomeFragment());
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();


        View headerView = navigationView.inflateHeaderView(R.layout.nav_header_main);
        TextView txtUserMail = headerView.findViewById(R.id.email_drawer);


        TextView mAuthButton = findViewById(R.id.btnAuth);
        if (FirebaseAuth.getInstance().getCurrentUser()==null){
            mAuthButton.setText("Login");
        }else{
            txtUserMail.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
            mAuthButton.setText("Logout");
        }


        mAuthButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mAuthButton.getText().toString().equalsIgnoreCase("login")){
                    startActivity(new Intent(Home.this, LoginSignUpActivity.class));

                }else{
                    new AlertDialog.Builder(Home.this)
                            .setTitle("Logout!")
                            .setMessage("Are you sure you want to logout?")
                            .setPositiveButton("Yes", (dialog, which) -> {
                                logOut();
                                dialog.dismiss();
                            })
                            .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                            .show();
                }
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        Fragment selectedFragment = null;


        if (id == R.id.privacy_policy_drawer) {
            if (privacyPolicyFragment==null){
                privacyPolicyFragment = new PrivacyPolicyFragment();
            }
            selectedFragment = privacyPolicyFragment;
        } else if (id == R.id.home_drawer) {
            if (homeFragment==null){
                homeFragment = new HomeFragment();
            }
            selectedFragment = homeFragment;
        }
        else if (id == R.id.car_rent_drawer) {
            if (rentACarFragment==null){
                rentACarFragment = new RentACarFragment();
            }
            selectedFragment = rentACarFragment;
        }else if (id == R.id.my_ads_drawer) {
            if (myAdsFragment==null){
                myAdsFragment = new MyAdsFragment();
            }
            selectedFragment = myAdsFragment;
        } else if (id == R.id.my_account_drawer) {
            if (profileFragment==null){
                profileFragment = new ProfileFragment();
            }
            selectedFragment = profileFragment;
        } else if (id == R.id.workshops_drawer) {
            if (workshopsFragment==null){
                workshopsFragment = new WorkshopsFragment();
            }
            selectedFragment = workshopsFragment;
        }else{
            if (homeFragment==null){
                homeFragment = new HomeFragment();
            }
            selectedFragment = homeFragment;
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, selectedFragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    private void logOut() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(Home.this, SplashScreen.class);
        startActivity(intent);
        finish();
    }
}